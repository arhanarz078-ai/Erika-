import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from openai import OpenAI

app = FastAPI(title="ERIKA AI Backend")
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)

@app.get("/health")
def health():
    return {"ok": True, "service": "ERIKA AI"}

@app.post("/chat")
def chat(body: ChatRequest):
    if not os.environ.get("OPENAI_API_KEY"):
        raise HTTPException(status_code=503, detail="Server API key is not configured")
    try:
        response = client.responses.create(
            model=os.environ.get("OPENAI_MODEL", "gpt-6-astra"),
            instructions=(
                "You are ERIKA, a helpful personal AI assistant. "
                "Speak naturally in Hindi, English, or Hinglish matching the user. "
                "Be concise, careful, and honest. You cannot directly control the phone "
                "from this endpoint; never claim an action was completed unless the app "
                "has actually executed and confirmed it. Ask before sensitive actions."
            ),
            input=body.message,
            tools=[{"type": "web_search"}],
        )
        return {"reply": response.output_text}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"AI request failed: {type(exc).__name__}")
