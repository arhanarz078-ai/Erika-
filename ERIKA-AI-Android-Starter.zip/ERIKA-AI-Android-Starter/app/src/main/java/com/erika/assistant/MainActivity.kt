package com.erika.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private val client = OkHttpClient()
    private var onSpeechResult: ((String) -> Unit)? = null

    private val speechLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val text = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!text.isNullOrBlank()) onSpeechResult?.invoke(text)
    }

    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) launchSpeech() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            ErikaScreen(
                onSend = { message, callback -> askErika(message, callback) },
                onSpeak = { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "erika-reply") },
                onMic = { callback ->
                    onSpeechResult = callback
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                        == PackageManager.PERMISSION_GRANTED) launchSpeech()
                    else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                }
            )
        }
    }

    private fun launchSpeech() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, " बोलिए, मैं सुन रही हूँ…")
        }
        try { speechLauncher.launch(intent) } catch (_: Exception) { }
    }

    private fun askErika(message: String, callback: (String) -> Unit) {
        val base = BuildConfig.BACKEND_URL.trimEnd('/')
        if (base.contains("YOUR-BACKEND-DOMAIN")) {
            callback("Backend URL set nahi hai. app/build.gradle.kts mein BACKEND_URL ko apne deployed HTTPS backend se replace karein.")
            return
        }
        val json = JSONObject().put("message", message).toString()
        val body = json.toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder().url("$base/chat").post(body).build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { callback("Network error: ${e.localizedMessage ?: "Please try again."}") }
            }
            override fun onResponse(call: Call, response: Response) {
                val raw = response.body?.string().orEmpty()
                val answer = try {
                    JSONObject(raw).optString("reply", "ERIKA ko response nahi mila.")
                } catch (_: Exception) { "Server response samajh nahi aaya: HTTP ${response.code}" }
                runOnUiThread { callback(answer) }
            }
        })
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            // Prefer Hindi voice; voice gender/availability depends on the installed TTS engine.
            val result = tts?.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.US)
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        client.dispatcher.executorService.shutdown()
        super.onDestroy()
    }
}

private data class ChatLine(val text: String, val isUser: Boolean)

@Composable
private fun ErikaScreen(
    onSend: (String, (String) -> Unit) -> Unit,
    onSpeak: (String) -> Unit,
    onMic: ((String) -> Unit) -> Unit
) {
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf(ChatLine("Namaste! Main ERIKA hoon. Aapki kis tarah madad kar sakti hoon?", false)) }

    val bg = Color(0xFF050914)
    val cyan = Color(0xFF00D9FF)

    MaterialTheme(colorScheme = darkColorScheme(
        primary = cyan, background = bg, surface = Color(0xFF101B2B),
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF071B38), bg, Color(0xFF100A24))
            )).padding(16.dp)
        ) {
            Text("ERIKA", style = MaterialTheme.typography.headlineLarge, color = cyan)
            Text("PERSONAL AI ASSISTANT", style = MaterialTheme.typography.labelSmall, color = Color.LightGray)
            Spacer(Modifier.height(18.dp))
            Box(
                Modifier.fillMaxWidth().height(130.dp)
                    .background(Color(0xFF0B2744), RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("◉", color = cyan, style = MaterialTheme.typography.displayLarge)
            }
            Spacer(Modifier.height(12.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(messages) { line ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement =
                        if (line.isUser) Arrangement.End else Arrangement.Start) {
                        Surface(
                            color = if (line.isUser) Color(0xFF075A78) else Color(0xFF17263A),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.widthIn(max = 310.dp)
                        ) { Text(line.text, Modifier.padding(12.dp), color = Color.White) }
                    }
                }
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Ask ERIKA anything…") },
                    maxLines = 4
                )
                IconButton(onClick = { onMic { input = it } }) {
                    Icon(Icons.Default.Mic, contentDescription = "Speak", tint = cyan)
                }
                IconButton(enabled = input.isNotBlank() && !busy, onClick = {
                    val question = input.trim()
                    input = ""
                    messages.add(ChatLine(question, true))
                    busy = true
                    onSend(question) { answer ->
                        messages.add(ChatLine(answer, false))
                        busy = false
                        onSpeak(answer)
                    }
                }) {
                    Icon(Icons.Default.Send, contentDescription = "Send", tint = cyan)
                }
            }
            Text("Voice recognition uses your device speech service. Replies use your configured ERIKA backend.",
                style = MaterialTheme.typography.labelSmall, color = Color.LightGray)
        }
    }
}
