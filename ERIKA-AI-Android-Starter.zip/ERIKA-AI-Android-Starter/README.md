# ERIKA AI Android Starter

This is a first working foundation: Compose chat UI, tap-to-talk speech input, Android TextToSpeech output, and a secure-backend chat request. It is not yet a full phone-control agent.

## Requirements
- Android Studio / JDK 17 / Android SDK 35, or GitHub Actions
- A deployed HTTPS backend
- A new OpenAI API key stored only as a backend environment variable

## 1. Deploy backend
1. Create a GitHub repository and upload the `backend/` folder contents to a separate backend repository (or deploy from this repo with the backend root configured).
2. Deploy the Python service on a host that supports FastAPI.
3. Set `OPENAI_API_KEY` in the host's environment/secrets dashboard. Never put it in Android code.
4. Set `OPENAI_MODEL` to a model available to your API project.
5. Verify `https://YOUR-HOST/health` returns `{"ok":true,"service":"ERIKA AI"}`.

For local backend testing:
```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export OPENAI_API_KEY="YOUR_NEW_KEY"
uvicorn main:app --reload
```

## 2. Configure Android
Edit `app/build.gradle.kts`:
```kotlin
buildConfigField("String", "BACKEND_URL", "\"https://YOUR-HOST\"")
```
Use HTTPS. Do not use a production APK with an HTTP backend.

## 3. Build APK in GitHub Actions
1. Create a GitHub repository and upload the Android project.
2. Open Actions > Build ERIKA Android APK > Run workflow.
3. Wait for the workflow to finish.
4. Open the successful run and download the `ERIKA-AI-debug-apk` artifact.
5. Extract the ZIP and install `app-debug.apk` on your phone. Allow installation from that source if Android asks.

## 4. Build locally
```bash
gradle assembleDebug
```
APK path:
`app/build/outputs/apk/debug/app-debug.apk`

## Current features
- Dark cyan/blue ERIKA interface
- Chat with the backend
- Android speech-recognition intent (tap microphone)
- Android TextToSpeech replies (Hindi locale fallback to English)
- Backend web-search tool enabled

## Not included yet
- Guaranteed female TTS voice (depends on installed Android speech engine/voice packs)
- Wake-word always listening
- Actual phone actions, notification reading, call/SMS workflows
- Durable user memory, authentication, rate limiting
- Windows companion

These require separate, permission-aware implementation and testing. Add authentication and rate limiting before exposing the backend publicly.
